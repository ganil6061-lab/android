package com.example.helloworld;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class cwa_array_adapter<T> extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_LOADING = 0;
    private static final int VIEW_TYPE_ITEM = 1;

    private List<T> itemList = new ArrayList<>();
    private int itemLayoutId;
    private Class<T> modelClass;
    private ViewBinder<T> viewBinder;
    private OnItemClickListener<T> clickListener;
    private boolean isLoading = true;

    public interface ViewBinder<T> {
        void bind(ViewHolder holder, T item, int position);
    }

    public interface OnItemClickListener<T> {
        void onClick(T item, int position);
    }

    public cwa_array_adapter(int itemLayoutId, Class<T> modelClass, ViewBinder<T> viewBinder) {
        this.itemLayoutId = itemLayoutId;
        this.modelClass = modelClass;
        this.viewBinder = viewBinder;
    }

    public void setOnItemClickListener(OnItemClickListener<T> listener) {
        this.clickListener = listener;
    }

    public void fetchData(String urlString) {
        isLoading = true;
        notifyDataSetChanged();

        Executors.newSingleThreadExecutor().execute(() -> {
            StringBuilder result = new StringBuilder();
            try {
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                reader.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            new Handler(Looper.getMainLooper()).post(() -> {
                isLoading = false;
                if (result.length() > 0) {
                    try {
                        Gson gson = new Gson();
                        Type listType = TypeToken.getParameterized(List.class, modelClass).getType();
                        List<T> parsedList = gson.fromJson(result.toString(), listType);
                        if (parsedList != null) {
                            this.itemList = parsedList;
                            notifyDataSetChanged();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    notifyDataSetChanged();
                }
            });
        });
    }

    @Override
    public int getItemViewType(int position) {
        if (isLoading) return VIEW_TYPE_LOADING;
        return VIEW_TYPE_ITEM;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
            return new LoadingViewHolder(view);
        }
        View view = LayoutInflater.from(parent.getContext()).inflate(itemLayoutId, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {
            T item = itemList.get(position);
            ViewHolder vh = (ViewHolder) holder;
            viewBinder.bind(vh, item, position);
            if (clickListener != null) {
                vh.itemView.setOnClickListener(v -> clickListener.onClick(item, position));
            }
        }
    }

    @Override
    public int getItemCount() {
        if (isLoading) return 1;
        return itemList.isEmpty() ? 0 : itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
        public void setText(int viewId, String text) {
            TextView tv = itemView.findViewById(viewId);
            if (tv != null) tv.setText(text);
        }
        public void setImage(int viewId, String imageUrl) {
            ImageView iv = itemView.findViewById(viewId);
            if (iv != null && imageUrl != null && !imageUrl.isEmpty()) {
                Glide.with(iv.getContext()).load(imageUrl).into(iv);
            }
        }
    }

    public static class LoadingViewHolder extends RecyclerView.ViewHolder {
        public LoadingViewHolder(@NonNull View itemView) { super(itemView); }
    }
}
