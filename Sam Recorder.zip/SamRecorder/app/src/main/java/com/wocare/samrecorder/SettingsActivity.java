package com.wocare.samrecorder;

import android.os.Bundle;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.materialswitch.MaterialSwitch;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Prefs prefs = new Prefs(this);
        MaterialSwitch swAudio = findViewById(R.id.swAudio);
        RadioGroup rg = findViewById(R.id.rgQuality);

        swAudio.setChecked(prefs.isAudioEnabled());
        switch (prefs.getQuality()) {
            case "480p":  rg.check(R.id.rb480);  break;
            case "1080p": rg.check(R.id.rb1080); break;
            default:      rg.check(R.id.rb720);
        }

        swAudio.setOnCheckedChangeListener((btn, checked) -> prefs.setAudioEnabled(checked));

        rg.setOnCheckedChangeListener((group, id) -> {
            if (id == R.id.rb480)       prefs.setQuality("480p");
            else if (id == R.id.rb1080) prefs.setQuality("1080p");
            else                        prefs.setQuality("720p");
        });
    }
}