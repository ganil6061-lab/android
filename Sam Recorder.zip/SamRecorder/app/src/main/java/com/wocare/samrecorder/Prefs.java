package com.wocare.samrecorder;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {

    private final SharedPreferences sp;

    public Prefs(Context context) {
        sp = context.getSharedPreferences("sr_prefs", Context.MODE_PRIVATE);
    }

    public boolean isAudioEnabled() {
        return sp.getBoolean("audio", true);
    }

    public void setAudioEnabled(boolean v) {
        sp.edit().putBoolean("audio", v).apply();
    }

    public String getQuality() {
        return sp.getString("quality", "720p");
    }

    public void setQuality(String q) {
        sp.edit().putString("quality", q).apply();
    }

    /** Screen size se quality cap karke even dimensions return karta hai */
    public int[] getVideoSize(int screenW, int screenH) {
        int maxDim;
        switch (getQuality()) {
            case "480p":  maxDim = 854;  break;
            case "1080p": maxDim = 1920; break;
            default:      maxDim = 1280;
        }
        float scale = Math.min(1f, (float) maxDim / Math.max(screenW, screenH));
        int w = ((int) (screenW * scale)) & -2;   // even number
        int h = ((int) (screenH * scale)) & -2;
        return new int[]{w, h};
    }

    public int getBitrate() {
        switch (getQuality()) {
            case "480p":  return 2_500_000;
            case "1080p": return 8_000_000;
            default:      return 5_000_000;
        }
    }
}