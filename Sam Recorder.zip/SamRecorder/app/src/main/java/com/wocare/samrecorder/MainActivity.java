package com.wocare.samrecorder;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btnRecord;
    private Prefs prefs;
    private MediaProjectionManager projectionManager;

    private final ActivityResultLauncher<Intent> projectionLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent intent = new Intent(this, RecordingService.class);
                    intent.setAction(RecordingService.ACTION_START);
                    intent.putExtra(RecordingService.EXTRA_RESULT_CODE, result.getResultCode());
                    intent.putExtra(RecordingService.EXTRA_RESULT_DATA, result.getData());
                    ContextCompat.startForegroundService(this, intent);
                } else {
                    Toast.makeText(this, "Screen recording permission denied",
                            Toast.LENGTH_SHORT).show();
                }
            });

    private final ActivityResultLauncher<String[]> permissionsLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                Boolean mic = result.get(Manifest.permission.RECORD_AUDIO);
                if (mic != null && !mic) {
                    Toast.makeText(this, "Mic denied → recording without audio",
                            Toast.LENGTH_SHORT).show();
                }
                requestScreenCapture();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new Prefs(this);
        projectionManager = getSystemService(MediaProjectionManager.class);

        btnRecord = findViewById(R.id.btnRecord);
        Button btnSettings = findViewById(R.id.btnSettings);

        btnSettings.setOnClickListener(v -> {
            Boolean rec = RecordingState.isRecording.getValue();
            if (rec == null || !rec) {
                startActivity(new Intent(this, SettingsActivity.class));
            } else {
                Toast.makeText(this, "Recording ke dauran settings nahi khul sakti",
                        Toast.LENGTH_SHORT).show();
            }
        });

        btnRecord.setOnClickListener(v -> {
            Boolean rec = RecordingState.isRecording.getValue();
            if (rec != null && rec) {
                Intent intent = new Intent(this, RecordingService.class);
                intent.setAction(RecordingService.ACTION_STOP);
                startService(intent);
            } else {
                startRecordingFlow();
            }
        });

        RecordingState.isRecording.observe(this, recording ->
                btnRecord.setText(Boolean.TRUE.equals(recording) ? "STOP" : "START"));
    }

    private void startRecordingFlow() {
        List<String> needed = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (prefs.isAudioEnabled() &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }

        if (!needed.isEmpty()) {
            permissionsLauncher.launch(needed.toArray(new String[0]));
        } else {
            requestScreenCapture();
        }
    }

    private void requestScreenCapture() {
        projectionLauncher.launch(projectionManager.createScreenCaptureIntent());
    }
}