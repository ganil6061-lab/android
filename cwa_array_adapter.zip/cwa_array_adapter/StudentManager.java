import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class StudentManager {

    // --- भाग 1: स्टूडेंट हेल्पर मेथड (जो रिसाइकलर व्यू को सेट करता है) ---
    public static void initStudentList(Context context, RecyclerView recyclerView, String jsonUrl) {
        
        recyclerView.setLayoutManager(new LinearLayoutManager(context));

        // cwa_array_adapter का इस्तेमाल
        cwa_array_adapter<StudentModel> adapter = new cwa_array_adapter<>(
            R.layout.item_row,       
            StudentModel.class,      // यहाँ हमने अंदर वाली मॉडल क्लास पास कर दी
            
            (holder, student, position) -> {
                holder.setText(R.id.tvName, student.getName());
                holder.setText(R.id.tvEmail, student.getEmail());
                holder.setImage(R.id.ivProfile, student.getImageUrl());
            }
        );

        // क्लिक करने पर नई एक्टिविटी खोलना
        adapter.setOnItemClickListener((student, position) -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("student_name", student.getName());
            context.startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
        adapter.fetchData(jsonUrl);
    }


    // --- भाग 2: मॉडल डाटा क्लास (Static Inner Class) ---
    public static class StudentModel {
        private String name;
        private String email;
        private String imageUrl;

        public StudentModel(String name, String email, String imageUrl) {
            this.name = name;
            this.email = email;
            this.imageUrl = imageUrl;
        }

        public String getName() { return name; }
        public String getEmail() { return email; }
        public String getImageUrl() { return imageUrl; }
    }
}