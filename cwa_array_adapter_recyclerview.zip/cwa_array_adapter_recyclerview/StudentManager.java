package com.example.helloworld;
import android.content.Context;
import android.content.Intent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class StudentManager {

    // --- भाग 1: स्टूडेंट हेल्पर मेथड (जो रिसाइकलर व्यू को सेट करता है) ---
    public static void initStudentList(Context context, RecyclerView recyclerView, String jsonUrl) {

        recyclerView.setLayoutManager(new LinearLayoutManager(context));

        // cwa_array_adapter का इस्तेमाल
        cwa_array_adapter<StudentModel> adapter = new cwa_array_adapter<>(
                R.layout.item_row,
                StudentModel.class,      // यहाँ हमने अंदर वाली मॉडल क्लास पास कर दी

                (holder, student, position) -> {
                    holder.setText(R.id.tvName, student.getName());

                }
        );

        // क्लिक करने पर नई एक्टिविटी खोलना
        adapter.setOnItemClickListener((student, position) -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("student_Dec", student.getDec());
            context.startActivity(intent);
        });

        recyclerView.setAdapter(adapter);
        adapter.fetchData(jsonUrl);
    }


    // --- भाग 2: मॉडल डाटा क्लास (Static Inner Class) ---
    public static class StudentModel {
        private String name;
        private String description;

        // Constructor
        public StudentModel(String name, String description) {
            this.name = name;
            this.description = description;
        }

        // --- Getters (Values lene ke liye) ---
        public String getName() {
            return name;
        }

        public String getDec() {
            return description;
        }

        // --- Setters (Values set ya change karne ke liye) ---
        public void setName(String name) {
            this.name = name;
        }

        public void setDec(String dec) {
            this.description = dec;
        }
    }
}