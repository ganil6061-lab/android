package com.example.helloworld;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class DetailActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);

        // Maan lijiye String data bheja gaya hai
        String receivedData = getIntent().getStringExtra("student_Dec");
        // XML me TextView ki id agar 'myTextView' hai
        TextView myTextView = findViewById(R.id.textView);
        myTextView.setText(receivedData);



    }
}