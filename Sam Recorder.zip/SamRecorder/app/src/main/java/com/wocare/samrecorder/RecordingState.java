package com.wocare.samrecorder;

import androidx.lifecycle.MutableLiveData;

public class RecordingState {
    public static final MutableLiveData<Boolean> isRecording = new MutableLiveData<>(false);
}