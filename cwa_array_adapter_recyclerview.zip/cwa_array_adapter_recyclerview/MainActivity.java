package com.example.helloworld;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        // GitHub या लिंक से डेटा लाने के लिए सिर्फ एक लाइन!
        String githubUrl = "jsonurl";

        StudentManager.initStudentList(this, recyclerView, githubUrl);
    }
}