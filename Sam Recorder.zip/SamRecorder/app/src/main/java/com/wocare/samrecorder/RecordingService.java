package com.wocare.samrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class RecordingService extends Service {

    public static final String ACTION_START = "start";
    public static final String ACTION_STOP  = "stop";
    public static final String EXTRA_RESULT_CODE = "rc";
    public static final String EXTRA_RESULT_DATA = "data";

    private static final String CHANNEL_ID = "sam_recorder_channel";
    private static final int    NOTIF_ID   = 101;

    private MediaRecorder recorder;
    private VirtualDisplay virtualDisplay;
    private MediaProjection projection;
    private File outputFile;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_START.equals(action)) {
                startAsForeground();
                int rc = intent.getIntExtra(EXTRA_RESULT_CODE, -1);
                Intent data;
                if (Build.VERSION.SDK_INT >= 33) {
                    data = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
                } else {
                    data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
                }
                if (data != null) startRecording(rc, data);
            } else if (ACTION_STOP.equals(action)) {
                stopRecordingInternal(true);
            }
        }
        return START_NOT_STICKY;
    }

    /** Android 14+/16 rule: startForeground() PEHLE, getMediaProjection() BAAD me */
    private void startAsForeground() {
        createChannel();
        Notification notif = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Sam Recorder")
                .setContentText("Recording in progress…")
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setOngoing(true)
                .build();

        boolean audioOn = new Prefs(this).isAudioEnabled();
        int serviceType = audioOn
                ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                | ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                : ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, serviceType);
        } else {
            startForeground(NOTIF_ID, notif);
        }
    }

    private void startRecording(int resultCode, Intent data) {
        try {
            Prefs prefs = new Prefs(this);
            MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
            projection = mpm.getMediaProjection(resultCode, data);

            // Android 16: lock screen / system stop par yahan aayega
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopRecordingInternal(true);
                }
            }, null);

            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int[] size = prefs.getVideoSize(metrics.widthPixels, metrics.heightPixels);
            int w = size[0], h = size[1];

            // Temporary file (app-private) — copy hone ke baad delete
            outputFile = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES),
                    "rec_" + System.currentTimeMillis() + ".mp4");

            boolean audioOn = prefs.isAudioEnabled();
            recorder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    ? new MediaRecorder(this)
                    : new MediaRecorder();

            recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            if (audioOn) recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            if (audioOn) recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setVideoSize(w, h);
            recorder.setVideoFrameRate(30);
            recorder.setVideoEncodingBitRate(prefs.getBitrate());
            recorder.setOutputFile(outputFile.getAbsolutePath());
            recorder.prepare();

            virtualDisplay = projection.createVirtualDisplay(
                    "SamRecorder", w, h, metrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    recorder.getSurface(), null, null);

            recorder.start();
            RecordingState.isRecording.postValue(true);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Recording failed: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
            stopRecordingInternal(false);
        }
    }

    private void stopRecordingInternal(boolean shouldSave) {
        try {
            if (recorder != null) recorder.stop();
        } catch (Exception ignored) {}
        if (recorder != null) {
            recorder.reset();
            recorder.release();
            recorder = null;
        }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (projection != null)    { projection.stop();        projection = null; }

        if (shouldSave && outputFile != null) saveToGallery(outputFile);
        outputFile = null;

        RecordingState.isRecording.postValue(false);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    /** Video ko /storage/emulated/0/DCIM/ScreenRecord/ me save karta hai */
    private void saveToGallery(File file) {
        if (!file.exists()) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, file.getName());
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");

            // ✅ DCIM/ScreenRecord folder
            values.put(MediaStore.Video.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_DCIM + "/ScreenRecord");

            values.put(MediaStore.Video.Media.IS_PENDING, 1);

            Uri uri = getContentResolver().insert(
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),
                    values);
            if (uri == null) return;

            try (OutputStream out = getContentResolver().openOutputStream(uri);
                 InputStream in  = new FileInputStream(file)) {
                if (out != null && in != null) {
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            values.clear();
            values.put(MediaStore.Video.Media.IS_PENDING, 0);
            getContentResolver().update(uri, values, null, null);

            // Temp file delete
            file.delete();

        } else {
            // Android 9 aur neeche — MediaScanner se Gallery me daalein
            MediaScannerConnection.scanFile(
                    this,
                    new String[]{file.getAbsolutePath()},
                    new String[]{"video/mp4"},
                    null);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL_ID, "Screen Recording",
                        NotificationManager.IMPORTANCE_LOW));
            }
        }
    }
}